# IT'S NOT ABOUT PRODUCTION... ITS ABOUT RESEARCH

Only color features doesn't work good, especially on 84x84 images.

Sometimes you need to delete 'ore' and S_Store file in datasets folder...
